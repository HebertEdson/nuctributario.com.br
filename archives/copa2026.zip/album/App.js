import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { Platform, View } from 'react-native';

import AlbumScreen from './src/screens/AlbumScreen';
import ScannerScreen from './src/screens/ScannerScreen';
import TrocasScreen from './src/screens/TrocasScreen';
import PerfilScreen from './src/screens/PerfilScreen';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerShown: false,
          tabBarStyle: {
            backgroundColor: '#fff',
            borderTopColor: '#f0f0f0',
            borderTopWidth: 1,
            height: Platform.OS === 'ios' ? 84 : 64,
            paddingBottom: Platform.OS === 'ios' ? 24 : 8,
            paddingTop: 8,
          },
          tabBarActiveTintColor: '#009C3B',
          tabBarInactiveTintColor: '#bbb',
          tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
          tabBarIcon: ({ color, size, focused }) => {
            const icons = {
              'Álbum': focused ? 'book' : 'book-outline',
              'Scanner': focused ? 'camera' : 'camera-outline',
              'Trocas': focused ? 'swap-horizontal' : 'swap-horizontal-outline',
              'Perfil': focused ? 'person' : 'person-outline',
            };
            return <Ionicons name={icons[route.name]} size={size} color={color} />;
          },
        })}
      >
        <Tab.Screen name="Álbum" component={AlbumScreen} />
        <Tab.Screen
          name="Scanner"
          component={ScannerScreen}
          options={{
            tabBarIcon: ({ color, focused }) => (
              <View style={{
                width: 52, height: 52, borderRadius: 26,
                backgroundColor: '#009C3B',
                alignItems: 'center', justifyContent: 'center',
                marginBottom: 20,
                shadowColor: '#009C3B', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.35, shadowRadius: 8, elevation: 8,
              }}>
                <Ionicons name="camera" size={26} color="#fff" />
              </View>
            ),
            tabBarLabel: () => null,
          }}
        />
        <Tab.Screen name="Trocas" component={TrocasScreen} />
        <Tab.Screen name="Perfil" component={PerfilScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
