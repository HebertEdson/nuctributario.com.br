import AsyncStorage from '@react-native-async-storage/async-storage';

const KEYS = {
  STICKERS: '@copa2026:stickers',
  PROFILE: '@copa2026:profile',
  TRADES: '@copa2026:trades',
};

// Stickers: { "BRA-5": 2, "ARG-11": 1, ... }
export const getStickers = async () => {
  try {
    const raw = await AsyncStorage.getItem(KEYS.STICKERS);
    return raw ? JSON.parse(raw) : {};
  } catch { return {}; }
};

export const saveStickers = async (stickers) => {
  await AsyncStorage.setItem(KEYS.STICKERS, JSON.stringify(stickers));
};

export const addSticker = async (key) => {
  const stickers = await getStickers();
  stickers[key] = (stickers[key] || 0) + 1;
  await saveStickers(stickers);
  return stickers;
};

export const removeSticker = async (key) => {
  const stickers = await getStickers();
  if (stickers[key] > 0) stickers[key] -= 1;
  if (stickers[key] === 0) delete stickers[key];
  await saveStickers(stickers);
  return stickers;
};

// Profile
export const getProfile = async () => {
  try {
    const raw = await AsyncStorage.getItem(KEYS.PROFILE);
    return raw ? JSON.parse(raw) : { name: '', city: '', whatsapp: '', avatar: '⚽' };
  } catch { return { name: '', city: '', whatsapp: '', avatar: '⚽' }; }
};

export const saveProfile = async (profile) => {
  await AsyncStorage.setItem(KEYS.PROFILE, JSON.stringify(profile));
};

// Stats
export const getStats = (stickers, total = 980) => {
  const keys = Object.keys(stickers);
  const owned = keys.filter(k => stickers[k] >= 1).length;
  const totalRepeated = keys.reduce((acc, k) => acc + Math.max(0, stickers[k] - 1), 0);
  const missing = total - owned;
  const pct = Math.round((owned / total) * 100);
  return { owned, missing, totalRepeated, pct };
};

export const getRepeatedList = (stickers) => {
  return Object.keys(stickers).filter(k => stickers[k] > 1);
};

export const getMissingList = (stickers, allKeys) => {
  return allKeys.filter(k => !stickers[k] || stickers[k] === 0);
};

export const resetAll = async () => {
  await AsyncStorage.multiRemove([KEYS.STICKERS, KEYS.PROFILE, KEYS.TRADES]);
};
