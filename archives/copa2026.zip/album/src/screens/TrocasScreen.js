import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  SafeAreaView, StatusBar, ScrollView, TextInput, Modal,
  Linking, Alert, Share
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { useCallback } from 'react';
import { getStickers, getRepeatedList, getProfile } from '../database/db';
import { SELECOES, getStickerKey } from '../data/album2026';

// Mock de outros usuários (em produção: backend real)
const MOCK_USERS = [
  {
    id: '1', name: 'Carlos Mendes', city: 'São Paulo, SP', avatar: 'CM', color: '#009C3B',
    distance: '2,3 km', online: true,
    have: [
      { selecaoId: 'BRA', num: 15, selecaoName: 'Brasil', flag: '🇧🇷', name: 'Vinicius Jr' },
      { selecaoId: 'ARG', num: 14, selecaoName: 'Argentina', flag: '🇦🇷', name: 'Julián Álvarez' },
      { selecaoId: 'ESP', num: 12, selecaoName: 'Espanha', flag: '🇪🇸', name: 'Álvaro Morata' },
    ],
    want: [
      { selecaoId: 'FRA', num: 12, selecaoName: 'França', flag: '🇫🇷', name: 'Kylian Mbappé' },
      { selecaoId: 'GER', num: 14, selecaoName: 'Alemanha', flag: '🇩🇪', name: 'Jamal Musiala' },
    ],
    whatsapp: '11999999999',
    trades: 14,
  },
  {
    id: '2', name: 'Ana Paula Silva', city: 'São Paulo, SP', avatar: 'AP', color: '#378ADD',
    distance: '4,1 km', online: true,
    have: [
      { selecaoId: 'FRA', num: 12, selecaoName: 'França', flag: '🇫🇷', name: 'Kylian Mbappé' },
      { selecaoId: 'ENG', num: 8, selecaoName: 'Inglaterra', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', name: 'Jude Bellingham' },
    ],
    want: [
      { selecaoId: 'BRA', num: 15, selecaoName: 'Brasil', flag: '🇧🇷', name: 'Vinicius Jr' },
      { selecaoId: 'POR', num: 11, selecaoName: 'Portugal', flag: '🇵🇹', name: 'Cristiano Ronaldo' },
    ],
    whatsapp: '11988888888',
    trades: 7,
  },
  {
    id: '3', name: 'Lucas Rocha', city: 'São Paulo, SP', avatar: 'LR', color: '#D85A30',
    distance: '6,7 km', online: false,
    have: [
      { selecaoId: 'GER', num: 14, selecaoName: 'Alemanha', flag: '🇩🇪', name: 'Jamal Musiala' },
      { selecaoId: 'NOR', num: 10, selecaoName: 'Noruega', flag: '🇳🇴', name: 'Erling Haaland' },
      { selecaoId: 'NED', num: 3, selecaoName: 'Holanda', flag: '🇳🇱', name: 'Virgil van Dijk' },
    ],
    want: [
      { selecaoId: 'ARG', num: 11, selecaoName: 'Argentina', flag: '🇦🇷', name: 'Lionel Messi' },
      { selecaoId: 'BRA', num: 16, selecaoName: 'Brasil', flag: '🇧🇷', name: 'Rodrygo' },
    ],
    whatsapp: '11977777777',
    trades: 23,
  },
  {
    id: '4', name: 'Mariana Costa', city: 'Guarulhos, SP', avatar: 'MC', color: '#BA7517',
    distance: '8,2 km', online: true,
    have: [
      { selecaoId: 'POR', num: 11, selecaoName: 'Portugal', flag: '🇵🇹', name: 'Cristiano Ronaldo' },
      { selecaoId: 'POR', num: 9, selecaoName: 'Portugal', flag: '🇵🇹', name: 'Bruno Fernandes' },
    ],
    want: [
      { selecaoId: 'ESP', num: 15, selecaoName: 'Espanha', flag: '🇪🇸', name: 'Lamine Yamal' },
      { selecaoId: 'FRA', num: 17, selecaoName: 'França', flag: '🇫🇷', name: 'Eduardo Camavinga' },
    ],
    whatsapp: '11966666666',
    trades: 5,
  },
  {
    id: '5', name: 'Rafael Nunes', city: 'Santo André, SP', avatar: 'RN', color: '#533AB7',
    distance: '12,4 km', online: false,
    have: [
      { selecaoId: 'ARG', num: 11, selecaoName: 'Argentina', flag: '🇦🇷', name: 'Lionel Messi' },
      { selecaoId: 'JPN', num: 9, selecaoName: 'Japão', flag: '🇯🇵', name: 'Takefusa Kubo' },
    ],
    want: [
      { selecaoId: 'BRA', num: 17, selecaoName: 'Brasil', flag: '🇧🇷', name: 'Estêvão' },
      { selecaoId: 'GER', num: 15, selecaoName: 'Alemanha', flag: '🇩🇪', name: 'Florian Wirtz' },
    ],
    whatsapp: '11955555555',
    trades: 31,
  },
];

export default function TrocasScreen() {
  const [myRepeated, setMyRepeated] = useState([]);
  const [myMissing, setMyMissing] = useState([]);
  const [users, setUsers] = useState(MOCK_USERS);
  const [selectedUser, setSelectedUser] = useState(null);
  const [filter, setFilter] = useState('all'); // 'all' | 'match'
  const [searchQuery, setSearchQuery] = useState('');

  useFocusEffect(useCallback(() => {
    loadMyData();
  }, []));

  const loadMyData = async () => {
    const stickers = await getStickers();
    const repeated = Object.keys(stickers)
      .filter(k => stickers[k] > 1)
      .map(k => {
        const [sid, num] = k.split('-');
        const sel = SELECOES.find(s => s.id === sid);
        const st = sel?.stickers.find(s => String(s.num) === num);
        return { key: k, selecaoId: sid, num, selecaoName: sel?.name || sid, flag: sel?.flag || '🏳️', name: st?.name || `#${num}`, count: stickers[k] };
      });
    setMyRepeated(repeated);
  };

  const matchScore = (user) => {
    const myRepKeys = myRepeated.map(r => getStickerKey(r.selecaoId, r.num));
    const haveMatch = user.have.filter(h => myRepKeys.includes(getStickerKey(h.selecaoId, h.num)));
    return haveMatch.length;
  };

  const filteredUsers = users
    .filter(u => {
      if (filter === 'match') return matchScore(u) > 0;
      if (searchQuery) {
        return u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          u.city.toLowerCase().includes(searchQuery.toLowerCase());
      }
      return true;
    })
    .sort((a, b) => {
      if (filter === 'match') return matchScore(b) - matchScore(a);
      return 0;
    });

  const openWhatsApp = (user) => {
    const myRepNames = myRepeated.map(r => `${r.flag} ${r.selecaoName} #${r.num}`).join(', ');
    const msg = `Olá ${user.name}! Vi seu perfil no app de figurinhas da Copa 2026. Tenho repetidas: ${myRepNames}. Podemos combinar uma troca?`;
    const url = `https://wa.me/55${user.whatsapp}?text=${encodeURIComponent(msg)}`;
    Linking.openURL(url).catch(() => Alert.alert('Erro', 'Não foi possível abrir o WhatsApp'));
  };

  const shareMyList = async () => {
    const repList = myRepeated.map(r => `${r.flag} ${r.selecaoName} #${r.num} (x${r.count - 1})`).join('\n');
    const msg = `Minhas figurinhas repetidas - Copa 2026 Panini:\n${repList || 'Nenhuma repetida ainda'}\n\nBaixe o app para gerenciar seu álbum!`;
    await Share.share({ message: msg });
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />

      <ScrollView stickyHeaderIndices={[0]} showsVerticalScrollIndicator={false}>
        {/* Sticky Header */}
        <View style={styles.stickyHeader}>
          <View style={styles.searchRow}>
            <View style={styles.searchBox}>
              <Ionicons name="search" size={16} color="#999" />
              <TextInput
                style={styles.searchInput}
                placeholder="Buscar pessoas..."
                placeholderTextColor="#bbb"
                value={searchQuery}
                onChangeText={setSearchQuery}
              />
            </View>
            <TouchableOpacity style={styles.shareBtn} onPress={shareMyList}>
              <Ionicons name="share-social" size={20} color="#009C3B" />
            </TouchableOpacity>
          </View>
          <View style={styles.filterRow}>
            <TouchableOpacity style={[styles.filterBtn, filter === 'all' && styles.filterBtnActive]} onPress={() => setFilter('all')}>
              <Text style={[styles.filterBtnText, filter === 'all' && styles.filterBtnTextActive]}>Todos</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.filterBtn, filter === 'match' && styles.filterBtnActive]} onPress={() => setFilter('match')}>
              <Ionicons name="sparkles" size={13} color={filter === 'match' ? '#fff' : '#999'} />
              <Text style={[styles.filterBtnText, filter === 'match' && styles.filterBtnTextActive]}>Combinam comigo</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Minhas Repetidas */}
        <View style={styles.myRepeatedSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Minhas repetidas ({myRepeated.length})</Text>
            <TouchableOpacity onPress={shareMyList}>
              <Text style={styles.shareLink}>Compartilhar</Text>
            </TouchableOpacity>
          </View>
          {myRepeated.length > 0 ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.repeatedChips}>
              {myRepeated.map(r => (
                <View key={r.key} style={styles.chip}>
                  <Text style={styles.chipFlag}>{r.flag}</Text>
                  <Text style={styles.chipText}>{r.selecaoId} #{r.num}</Text>
                  {r.count > 2 && <View style={styles.chipBadge}><Text style={styles.chipBadgeText}>x{r.count - 1}</Text></View>}
                </View>
              ))}
            </ScrollView>
          ) : (
            <View style={styles.emptyRepeated}>
              <Text style={styles.emptyRepeatedText}>Nenhuma figurinha repetida ainda. Abra mais envelopes! 📦</Text>
            </View>
          )}
        </View>

        {/* Online count */}
        <View style={styles.onlineRow}>
          <View style={styles.onlineDot} />
          <Text style={styles.onlineText}>{MOCK_USERS.filter(u => u.online).length} pessoas online agora</Text>
        </View>

        {/* Users */}
        {filteredUsers.map(user => {
          const score = matchScore(user);
          return (
            <TouchableOpacity key={user.id} style={styles.userCard} onPress={() => setSelectedUser(user)} activeOpacity={0.7}>
              <View style={styles.userTop}>
                <View style={[styles.avatar, { backgroundColor: user.color + '22' }]}>
                  <Text style={[styles.avatarText, { color: user.color }]}>{user.avatar}</Text>
                </View>
                <View style={styles.userInfo}>
                  <View style={styles.userNameRow}>
                    <Text style={styles.userName}>{user.name}</Text>
                    {user.online && <View style={styles.onlinePill}><View style={styles.onlineDotSmall} /><Text style={styles.onlinePillText}>online</Text></View>}
                  </View>
                  <Text style={styles.userCity}>{user.city} · {user.distance}</Text>
                  <Text style={styles.userTrades}>{user.trades} trocas realizadas</Text>
                </View>
              </View>

              {score > 0 && (
                <View style={styles.matchBanner}>
                  <Ionicons name="sparkles" size={14} color="#005c23" />
                  <Text style={styles.matchText}>Tem {score} figurinha{score > 1 ? 's' : ''} que você precisa!</Text>
                </View>
              )}

              <View style={styles.userStickers}>
                <View style={styles.userStickerGroup}>
                  <Text style={styles.userStickerLabel}>TEM</Text>
                  <View style={styles.stickerChips}>
                    {user.have.map(h => (
                      <View key={`${h.selecaoId}-${h.num}`} style={styles.haveChip}>
                        <Text style={styles.chipFlagSm}>{h.flag}</Text>
                        <Text style={styles.haveChipText}>{h.selecaoId} #{h.num}</Text>
                      </View>
                    ))}
                  </View>
                </View>
                <View style={styles.userStickerGroup}>
                  <Text style={[styles.userStickerLabel, { color: '#378ADD' }]}>BUSCA</Text>
                  <View style={styles.stickerChips}>
                    {user.want.map(w => (
                      <View key={`${w.selecaoId}-${w.num}`} style={styles.wantChip}>
                        <Text style={styles.chipFlagSm}>{w.flag}</Text>
                        <Text style={styles.wantChipText}>{w.selecaoId} #{w.num}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              </View>

              <TouchableOpacity style={styles.whatsappBtn} onPress={() => openWhatsApp(user)}>
                <Ionicons name="logo-whatsapp" size={18} color="#fff" />
                <Text style={styles.whatsappBtnText}>Propor troca</Text>
              </TouchableOpacity>
            </TouchableOpacity>
          );
        })}
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f8f8f8' },
  stickyHeader: { backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#f0f0f0', paddingBottom: 8 },
  searchRow: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 12, paddingBottom: 8 },
  searchBox: { flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: '#f5f5f5', borderRadius: 10, paddingHorizontal: 10, height: 38, gap: 6 },
  searchInput: { flex: 1, fontSize: 14, color: '#333' },
  shareBtn: { padding: 8 },
  filterRow: { flexDirection: 'row', gap: 8, paddingHorizontal: 12 },
  filterBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: '#f5f5f5' },
  filterBtnActive: { backgroundColor: '#009C3B' },
  filterBtnText: { fontSize: 13, color: '#666', fontWeight: '500' },
  filterBtnTextActive: { color: '#fff' },

  myRepeatedSection: { backgroundColor: '#fff', margin: 12, marginBottom: 0, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: '#f0f0f0' },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  sectionTitle: { fontSize: 13, fontWeight: '700', color: '#222' },
  shareLink: { fontSize: 12, color: '#009C3B', fontWeight: '600' },
  repeatedChips: { gap: 6, paddingVertical: 2 },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#FAEEDA', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 5, position: 'relative' },
  chipFlag: { fontSize: 14 },
  chipText: { fontSize: 12, color: '#7a4000', fontWeight: '500' },
  chipBadge: { backgroundColor: '#EF9F27', borderRadius: 8, paddingHorizontal: 4, paddingVertical: 1 },
  chipBadgeText: { color: '#fff', fontSize: 9, fontWeight: '700' },
  emptyRepeated: { backgroundColor: '#f8f8f8', borderRadius: 10, padding: 12 },
  emptyRepeatedText: { fontSize: 13, color: '#999', textAlign: 'center' },

  onlineRow: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 16, paddingVertical: 10 },
  onlineDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#009C3B' },
  onlineText: { fontSize: 12, color: '#666' },

  userCard: { backgroundColor: '#fff', marginHorizontal: 12, marginBottom: 10, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: '#f0f0f0' },
  userTop: { flexDirection: 'row', gap: 10, marginBottom: 10 },
  avatar: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 14, fontWeight: '700' },
  userInfo: { flex: 1 },
  userNameRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  userName: { fontSize: 14, fontWeight: '700', color: '#222' },
  onlinePill: { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: '#e6f7ec', borderRadius: 10, paddingHorizontal: 6, paddingVertical: 2 },
  onlineDotSmall: { width: 5, height: 5, borderRadius: 3, backgroundColor: '#009C3B' },
  onlinePillText: { fontSize: 10, color: '#009C3B', fontWeight: '600' },
  userCity: { fontSize: 11, color: '#999', marginTop: 2 },
  userTrades: { fontSize: 11, color: '#bbb', marginTop: 1 },

  matchBanner: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: '#e6f7ec', borderRadius: 8, padding: 8, marginBottom: 10 },
  matchText: { fontSize: 12, color: '#005c23', fontWeight: '600' },

  userStickers: { gap: 6, marginBottom: 12 },
  userStickerGroup: {},
  userStickerLabel: { fontSize: 10, color: '#009C3B', fontWeight: '700', marginBottom: 4, letterSpacing: 0.5 },
  stickerChips: { flexDirection: 'row', flexWrap: 'wrap', gap: 5 },
  haveChip: { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: '#e6f7ec', borderRadius: 8, paddingHorizontal: 7, paddingVertical: 3 },
  haveChipText: { fontSize: 11, color: '#005c23', fontWeight: '500' },
  wantChip: { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: '#e6edf8', borderRadius: 8, paddingHorizontal: 7, paddingVertical: 3 },
  wantChipText: { fontSize: 11, color: '#0c447c', fontWeight: '500' },
  chipFlagSm: { fontSize: 12 },

  whatsappBtn: { backgroundColor: '#25D366', borderRadius: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 10 },
  whatsappBtnText: { color: '#fff', fontSize: 14, fontWeight: '700' },
});
