import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, SafeAreaView,
  StatusBar, Alert, TextInput, FlatList, ActivityIndicator, ScrollView, Modal
} from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { Ionicons } from '@expo/vector-icons';
import { SELECOES, getStickerKey } from '../data/album2026';
import { addSticker, getStickers } from '../database/db';

// Simula reconhecimento por IA (em produção, conectar à API de visão)
const recognizeSticker = async (imageBase64) => {
  await new Promise(r => setTimeout(r, 1500));
  const randoms = [
    { selecaoId: 'BRA', num: 11, name: 'Vinicius Jr - FWD', selecaoName: 'Brasil', flag: '🇧🇷', confidence: 0.96 },
    { selecaoId: 'ARG', num: 11, name: 'Lionel Messi - FWD', selecaoName: 'Argentina', flag: '🇦🇷', confidence: 0.94 },
    { selecaoId: 'FRA', num: 12, name: 'Kylian Mbappé - FWD', selecaoName: 'França', flag: '🇫🇷', confidence: 0.91 },
    { selecaoId: 'NOR', num: 10, name: 'Erling Haaland - FWD', selecaoName: 'Noruega', flag: '🇳🇴', confidence: 0.89 },
    { selecaoId: 'POR', num: 11, name: 'Cristiano Ronaldo - FWD', selecaoName: 'Portugal', flag: '🇵🇹', confidence: 0.95 },
    { selecaoId: 'ENG', num: 10, name: 'Harry Kane - FWD', selecaoName: 'Inglaterra', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', confidence: 0.88 },
    { selecaoId: 'GER', num: 14, name: 'Jamal Musiala - MID', selecaoName: 'Alemanha', flag: '🇩🇪', confidence: 0.90 },
    { selecaoId: 'BRA', num: 1, name: 'Escudo + Maracanã', selecaoName: 'Brasil', flag: '🇧🇷', confidence: 0.98 },
  ];
  return randoms[Math.floor(Math.random() * randoms.length)];
};

export default function ScannerScreen() {
  const [permission, requestPermission] = useCameraPermissions();
  const [mode, setMode] = useState('camera'); // 'camera' | 'manual'
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState(null);
  const [stickers, setStickers] = useState({});
  const [manualSearch, setManualSearch] = useState('');
  const [manualResults, setManualResults] = useState([]);
  const [toast, setToast] = useState(null);
  const [recentAdded, setRecentAdded] = useState([]);
  const cameraRef = useRef(null);

  useEffect(() => {
    getStickers().then(setStickers);
  }, []);

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 2500);
  };

  const handleCapture = async () => {
    if (!cameraRef.current || scanning) return;
    try {
      setScanning(true);
      const photo = await cameraRef.current.takePictureAsync({ base64: true, quality: 0.7 });
      const recognized = await recognizeSticker(photo.base64);
      setResult(recognized);
    } catch (e) {
      showToast('Erro ao capturar foto', 'error');
    } finally {
      setScanning(false);
    }
  };

  const confirmAdd = async (item) => {
    const key = getStickerKey(item.selecaoId, item.num);
    const newStickers = await addSticker(key);
    setStickers(newStickers);
    const count = newStickers[key];
    const msg = count > 1 ? `${item.flag} ${item.selecaoName} #${item.num} — repetida! (x${count})` : `${item.flag} ${item.selecaoName} #${item.num} adicionada!`;
    showToast(msg, count > 1 ? 'warn' : 'success');
    setRecentAdded(prev => [{ ...item, key, count, time: Date.now() }, ...prev.slice(0, 9)]);
    setResult(null);
  };

  const handleManualSearch = (text) => {
    setManualSearch(text);
    if (!text.trim()) { setManualResults([]); return; }
    const lower = text.toLowerCase();
    const results = [];
    for (const s of SELECOES) {
      if (results.length >= 10) break;
      for (const st of s.stickers) {
        const key = getStickerKey(s.id, st.num);
        const count = stickers[key] || 0;
        if (
          s.name.toLowerCase().includes(lower) ||
          s.id.toLowerCase().includes(lower) ||
          String(st.num).includes(text) ||
          st.name.toLowerCase().includes(lower)
        ) {
          results.push({ selecaoId: s.id, selecaoName: s.name, flag: s.flag, color: s.color, num: st.num, name: st.name, count });
          if (results.length >= 10) break;
        }
      }
    }
    setManualResults(results);
  };

  if (!permission) return <View style={styles.center}><ActivityIndicator color="#009C3B" /></View>;

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />

      {/* Tabs */}
      <View style={styles.modeTabs}>
        <TouchableOpacity style={[styles.modeTab, mode === 'camera' && styles.modeTabActive]} onPress={() => setMode('camera')}>
          <Ionicons name="camera" size={18} color={mode === 'camera' ? '#009C3B' : '#999'} />
          <Text style={[styles.modeTabText, mode === 'camera' && styles.modeTabTextActive]}>Câmera</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.modeTab, mode === 'manual' && styles.modeTabActive]} onPress={() => setMode('manual')}>
          <Ionicons name="search" size={18} color={mode === 'manual' ? '#009C3B' : '#999'} />
          <Text style={[styles.modeTabText, mode === 'manual' && styles.modeTabTextActive]}>Manual</Text>
        </TouchableOpacity>
      </View>

      {mode === 'camera' ? (
        <View style={styles.cameraContainer}>
          {!permission.granted ? (
            <View style={styles.center}>
              <Ionicons name="camera-off" size={48} color="#ccc" />
              <Text style={styles.permText}>Câmera não autorizada</Text>
              <TouchableOpacity style={styles.permBtn} onPress={requestPermission}>
                <Text style={styles.permBtnText}>Permitir câmera</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <>
              <CameraView ref={cameraRef} style={styles.camera} facing="back">
                {/* Viewfinder */}
                <View style={styles.viewfinder}>
                  <View style={[styles.corner, styles.cornerTL]} />
                  <View style={[styles.corner, styles.cornerTR]} />
                  <View style={[styles.corner, styles.cornerBL]} />
                  <View style={[styles.corner, styles.cornerBR]} />
                  {scanning && (
                    <View style={styles.scanningOverlay}>
                      <ActivityIndicator size="large" color="#fff" />
                      <Text style={styles.scanningText}>Identificando figurinha...</Text>
                    </View>
                  )}
                </View>
                <Text style={styles.cameraHint}>Aponte para a figurinha</Text>
              </CameraView>

              <View style={styles.captureRow}>
                <TouchableOpacity style={[styles.captureBtn, scanning && styles.captureBtnDisabled]} onPress={handleCapture} disabled={scanning}>
                  <View style={styles.captureBtnInner}>
                    <Ionicons name="camera" size={28} color={scanning ? '#ccc' : '#fff'} />
                  </View>
                </TouchableOpacity>
              </View>
            </>
          )}
        </View>
      ) : (
        <ScrollView style={styles.manualContainer} keyboardShouldPersistTaps="handled">
          <View style={styles.searchBox}>
            <Ionicons name="search" size={18} color="#999" />
            <TextInput
              style={styles.searchInput}
              placeholder="Buscar por seleção, jogador ou número..."
              placeholderTextColor="#bbb"
              value={manualSearch}
              onChangeText={handleManualSearch}
              autoFocus
            />
            {manualSearch ? <TouchableOpacity onPress={() => { setManualSearch(''); setManualResults([]); }}><Ionicons name="close-circle" size={18} color="#bbb" /></TouchableOpacity> : null}
          </View>

          {manualResults.length > 0 && manualResults.map(item => {
            const isOwned = item.count >= 1;
            const isRepeated = item.count > 1;
            return (
              <TouchableOpacity key={`${item.selecaoId}-${item.num}`} style={styles.manualItem} onPress={() => confirmAdd(item)}>
                <Text style={styles.manualFlag}>{item.flag}</Text>
                <View style={styles.manualInfo}>
                  <Text style={styles.manualName}>{item.name}</Text>
                  <Text style={styles.manualSel}>{item.selecaoName} · #{item.num}</Text>
                </View>
                <View style={[styles.manualStatus, isRepeated ? styles.statusRepeated : isOwned ? styles.statusOwned : styles.statusMissing]}>
                  <Text style={[styles.manualStatusText, isRepeated ? { color: '#7a4000' } : isOwned ? { color: '#005c23' } : { color: '#666' }]}>
                    {isRepeated ? `x${item.count}` : isOwned ? '✓' : '+ Add'}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          })}

          {manualSearch && manualResults.length === 0 && (
            <View style={styles.center}>
              <Ionicons name="search" size={32} color="#ddd" />
              <Text style={styles.emptyText}>Nenhuma figurinha encontrada</Text>
            </View>
          )}
        </ScrollView>
      )}

      {/* Recentes */}
      {recentAdded.length > 0 && (
        <View style={styles.recentSection}>
          <Text style={styles.recentTitle}>Adicionadas recentemente</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {recentAdded.map(item => (
              <View key={item.key + item.time} style={[styles.recentChip, item.count > 1 && styles.recentChipRepeated]}>
                <Text style={styles.recentChipFlag}>{item.flag}</Text>
                <Text style={styles.recentChipText}>{item.selecaoId} #{item.num}</Text>
                {item.count > 1 && <Text style={styles.recentChipBadge}>x{item.count}</Text>}
              </View>
            ))}
          </ScrollView>
        </View>
      )}

      {/* Result Modal */}
      <Modal visible={!!result} transparent animationType="slide" onRequestClose={() => setResult(null)}>
        {result && (
          <View style={styles.resultOverlay}>
            <View style={styles.resultCard}>
              <View style={styles.resultHeader}>
                <Text style={styles.resultFlag}>{result.flag}</Text>
                <View>
                  <Text style={styles.resultName}>{result.name}</Text>
                  <Text style={styles.resultSel}>{result.selecaoName} · Figurinha #{result.num}</Text>
                  <Text style={styles.resultConf}>Confiança: {Math.round(result.confidence * 100)}%</Text>
                </View>
              </View>

              {stickers[getStickerKey(result.selecaoId, result.num)] > 0 && (
                <View style={styles.warningBanner}>
                  <Ionicons name="warning" size={16} color="#7a4000" />
                  <Text style={styles.warningText}>
                    Você já tem {stickers[getStickerKey(result.selecaoId, result.num)]}x essa figurinha. Será repetida!
                  </Text>
                </View>
              )}

              <View style={styles.resultActions}>
                <TouchableOpacity style={styles.resultConfirm} onPress={() => confirmAdd(result)}>
                  <Ionicons name="checkmark" size={20} color="#fff" />
                  <Text style={styles.resultConfirmText}>Adicionar ao álbum</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.resultCancel} onPress={() => setResult(null)}>
                  <Text style={styles.resultCancelText}>Não era essa</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}
      </Modal>

      {/* Toast */}
      {toast && (
        <View style={[styles.toast, toast.type === 'error' ? styles.toastError : toast.type === 'warn' ? styles.toastWarn : styles.toastSuccess]}>
          <Text style={styles.toastText}>{toast.msg}</Text>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#fff' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  modeTabs: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  modeTab: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 12, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  modeTabActive: { borderBottomColor: '#009C3B' },
  modeTabText: { fontSize: 14, color: '#999', fontWeight: '500' },
  modeTabTextActive: { color: '#009C3B' },

  cameraContainer: { flex: 1 },
  camera: { flex: 1 },
  viewfinder: {
    position: 'absolute', top: '50%', left: '50%',
    marginTop: -120, marginLeft: -120,
    width: 240, height: 160,
    justifyContent: 'center', alignItems: 'center',
  },
  corner: { position: 'absolute', width: 24, height: 24, borderColor: '#fff', borderWidth: 3 },
  cornerTL: { top: 0, left: 0, borderRightWidth: 0, borderBottomWidth: 0 },
  cornerTR: { top: 0, right: 0, borderLeftWidth: 0, borderBottomWidth: 0 },
  cornerBL: { bottom: 0, left: 0, borderRightWidth: 0, borderTopWidth: 0 },
  cornerBR: { bottom: 0, right: 0, borderLeftWidth: 0, borderTopWidth: 0 },
  scanningOverlay: { position: 'absolute', alignItems: 'center', gap: 8 },
  scanningText: { color: '#fff', fontSize: 14, fontWeight: '600', textShadowColor: 'rgba(0,0,0,0.5)', textShadowOffset: { width: 1, height: 1 }, textShadowRadius: 2 },
  cameraHint: { position: 'absolute', bottom: 16, width: '100%', textAlign: 'center', color: 'rgba(255,255,255,0.85)', fontSize: 13, textShadowColor: 'rgba(0,0,0,0.5)', textShadowOffset: { width: 1, height: 1 }, textShadowRadius: 2 },
  captureRow: { backgroundColor: '#111', paddingVertical: 24, alignItems: 'center' },
  captureBtn: { width: 72, height: 72, borderRadius: 36, backgroundColor: '#009C3B', alignItems: 'center', justifyContent: 'center', borderWidth: 4, borderColor: 'rgba(255,255,255,0.3)' },
  captureBtnDisabled: { backgroundColor: '#444' },
  captureBtnInner: { alignItems: 'center', justifyContent: 'center' },

  manualContainer: { flex: 1, padding: 12 },
  searchBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f5f5f5', borderRadius: 12, paddingHorizontal: 12, height: 44, gap: 8, marginBottom: 12 },
  searchInput: { flex: 1, fontSize: 15, color: '#333' },
  manualItem: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 12, padding: 12, marginBottom: 8, borderWidth: 1, borderColor: '#f0f0f0', gap: 10 },
  manualFlag: { fontSize: 28 },
  manualInfo: { flex: 1 },
  manualName: { fontSize: 13, fontWeight: '600', color: '#222' },
  manualSel: { fontSize: 11, color: '#999', marginTop: 2 },
  manualStatus: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8 },
  statusOwned: { backgroundColor: '#e6f7ec' },
  statusRepeated: { backgroundColor: '#FAEEDA' },
  statusMissing: { backgroundColor: '#f0f0f0' },
  manualStatusText: { fontSize: 12, fontWeight: '600' },
  emptyText: { color: '#ccc', fontSize: 14, marginTop: 8 },

  recentSection: { backgroundColor: '#f8f8f8', padding: 12, borderTopWidth: 1, borderTopColor: '#f0f0f0' },
  recentTitle: { fontSize: 11, color: '#999', marginBottom: 8, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.5 },
  recentChip: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#e6f7ec', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 5, marginRight: 6 },
  recentChipRepeated: { backgroundColor: '#FAEEDA' },
  recentChipFlag: { fontSize: 14 },
  recentChipText: { fontSize: 12, color: '#333', fontWeight: '500' },
  recentChipBadge: { fontSize: 10, color: '#EF9F27', fontWeight: '700' },

  resultOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  resultCard: { backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24 },
  resultHeader: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 16 },
  resultFlag: { fontSize: 48 },
  resultName: { fontSize: 16, fontWeight: '700', color: '#222' },
  resultSel: { fontSize: 13, color: '#666', marginTop: 2 },
  resultConf: { fontSize: 11, color: '#009C3B', marginTop: 4, fontWeight: '600' },
  warningBanner: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#FAEEDA', borderRadius: 10, padding: 10, marginBottom: 14 },
  warningText: { fontSize: 12, color: '#7a4000', flex: 1 },
  resultActions: { gap: 8 },
  resultConfirm: { backgroundColor: '#009C3B', borderRadius: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 14 },
  resultConfirmText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  resultCancel: { alignItems: 'center', paddingVertical: 12 },
  resultCancelText: { color: '#999', fontSize: 14 },

  permText: { color: '#999', fontSize: 15, marginTop: 12, marginBottom: 16 },
  permBtn: { backgroundColor: '#009C3B', borderRadius: 12, paddingHorizontal: 24, paddingVertical: 12 },
  permBtnText: { color: '#fff', fontSize: 15, fontWeight: '600' },

  toast: { position: 'absolute', bottom: 24, left: 16, right: 16, borderRadius: 12, padding: 14, alignItems: 'center' },
  toastSuccess: { backgroundColor: '#009C3B' },
  toastError: { backgroundColor: '#E24B4A' },
  toastWarn: { backgroundColor: '#EF9F27' },
  toastText: { color: '#fff', fontSize: 13, fontWeight: '600', textAlign: 'center' },
});
