import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  SafeAreaView, StatusBar, TextInput, Alert, Modal
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { getStickers, getProfile, saveProfile, getStats, resetAll } from '../database/db';
import { SELECOES, TOTAL_STICKERS, getStickerKey } from '../data/album2026';

export default function PerfilScreen() {
  const [stickers, setStickers] = useState({});
  const [stats, setStats] = useState({ owned: 0, missing: 980, totalRepeated: 0, pct: 0 });
  const [profile, setProfileState] = useState({ name: '', city: '', whatsapp: '', avatar: '⚽' });
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({});

  useFocusEffect(useCallback(() => {
    load();
  }, []));

  const load = async () => {
    const [s, p] = await Promise.all([getStickers(), getProfile()]);
    setStickers(s);
    setStats(getStats(s, TOTAL_STICKERS));
    setProfileState(p);
    setForm(p);
  };

  const handleSave = async () => {
    await saveProfile(form);
    setProfileState(form);
    setEditing(false);
  };

  const handleReset = () => {
    Alert.alert(
      'Resetar álbum',
      'Isso vai apagar TODAS as suas figurinhas e dados. Tem certeza?',
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Resetar tudo', style: 'destructive', onPress: async () => {
          await resetAll();
          await load();
        }},
      ]
    );
  };

  // Stats por grupo
  const groupStats = (() => {
    const groups = {};
    SELECOES.forEach(s => {
      const owned = s.stickers.filter(st => (stickers[getStickerKey(s.id, st.num)] || 0) >= 1).length;
      const pct = Math.round(owned / s.stickers.length * 100);
      if (!groups[s.group]) groups[s.group] = { owned: 0, total: 0 };
      groups[s.group].owned += owned;
      groups[s.group].total += s.stickers.length;
    });
    return groups;
  })();

  // Seleções mais completas
  const topSelecoes = [...SELECOES]
    .map(s => {
      const owned = s.stickers.filter(st => (stickers[getStickerKey(s.id, st.num)] || 0) >= 1).length;
      return { ...s, owned, pct: Math.round(owned / s.stickers.length * 100) };
    })
    .filter(s => s.owned > 0)
    .sort((a, b) => b.pct - a.pct)
    .slice(0, 5);

  const repeatedList = Object.keys(stickers)
    .filter(k => stickers[k] > 1)
    .map(k => {
      const [sid, num] = k.split('-');
      const sel = SELECOES.find(s => s.id === sid);
      return { key: k, selecaoId: sid, num, flag: sel?.flag || '🏳️', count: stickers[k] };
    });

  const avatarOptions = ['⚽', '🏆', '🇧🇷', '⭐', '🥅', '🎯'];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />
      <ScrollView showsVerticalScrollIndicator={false}>

        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <TouchableOpacity onPress={() => setEditing(true)} style={styles.avatarWrap}>
            <Text style={styles.avatarEmoji}>{profile.avatar || '⚽'}</Text>
          </TouchableOpacity>
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>{profile.name || 'Seu nome'}</Text>
            <Text style={styles.profileCity}>{profile.city || 'Sua cidade'}</Text>
          </View>
          <TouchableOpacity style={styles.editBtn} onPress={() => setEditing(true)}>
            <Ionicons name="pencil" size={16} color="#009C3B" />
          </TouchableOpacity>
        </View>

        {/* Main Stats */}
        <View style={styles.statsCard}>
          <View style={styles.bigStat}>
            <Text style={styles.bigStatNum}>{stats.pct}%</Text>
            <Text style={styles.bigStatLbl}>do álbum completo</Text>
          </View>
          <View style={styles.progressTrack}>
            <View style={[styles.progressFill, { width: `${stats.pct}%` }]} />
          </View>
          <View style={styles.statsGrid}>
            <View style={styles.statItem}>
              <Text style={[styles.statNum, { color: '#009C3B' }]}>{stats.owned}</Text>
              <Text style={styles.statLbl}>Tenho</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={[styles.statNum, { color: '#E24B4A' }]}>{stats.missing}</Text>
              <Text style={styles.statLbl}>Faltam</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={[styles.statNum, { color: '#EF9F27' }]}>{stats.totalRepeated}</Text>
              <Text style={styles.statLbl}>Repetidas</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statNum}>{TOTAL_STICKERS}</Text>
              <Text style={styles.statLbl}>Total</Text>
            </View>
          </View>
        </View>

        {/* Por Grupo */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Progresso por Grupo</Text>
          {Object.entries(groupStats).sort(([a], [b]) => a.localeCompare(b)).map(([group, data]) => {
            const pct = Math.round(data.owned / data.total * 100);
            return (
              <View key={group} style={styles.groupRow}>
                <Text style={styles.groupLabel}>Grupo {group}</Text>
                <View style={styles.groupTrack}>
                  <View style={[styles.groupFill, { width: `${pct}%` }]} />
                </View>
                <Text style={styles.groupPct}>{pct}%</Text>
                <Text style={styles.groupCount}>{data.owned}/{data.total}</Text>
              </View>
            );
          })}
        </View>

        {/* Top Seleções */}
        {topSelecoes.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Seleções mais completas</Text>
            {topSelecoes.map(s => (
              <View key={s.id} style={styles.topSelRow}>
                <Text style={styles.topSelFlag}>{s.flag}</Text>
                <Text style={styles.topSelName}>{s.name}</Text>
                <View style={styles.topSelTrack}>
                  <View style={[styles.topSelFill, { width: `${s.pct}%`, backgroundColor: s.color }]} />
                </View>
                <Text style={[styles.topSelPct, { color: s.color }]}>{s.pct}%</Text>
              </View>
            ))}
          </View>
        )}

        {/* Repetidas */}
        {repeatedList.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Todas as repetidas ({repeatedList.length})</Text>
            <View style={styles.repeatedGrid}>
              {repeatedList.map(r => (
                <View key={r.key} style={styles.repChip}>
                  <Text style={styles.repFlag}>{r.flag}</Text>
                  <Text style={styles.repKey}>{r.selecaoId}-{r.num}</Text>
                  <Text style={styles.repCount}>x{r.count - 1}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Reset */}
        <View style={styles.section}>
          <TouchableOpacity style={styles.resetBtn} onPress={handleReset}>
            <Ionicons name="trash-outline" size={18} color="#E24B4A" />
            <Text style={styles.resetBtnText}>Resetar álbum</Text>
          </TouchableOpacity>
        </View>

        <View style={{ height: 30 }} />
      </ScrollView>

      {/* Edit Modal */}
      <Modal visible={editing} animationType="slide" transparent onRequestClose={() => setEditing(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeaderRow}>
              <Text style={styles.modalTitle}>Editar Perfil</Text>
              <TouchableOpacity onPress={() => setEditing(false)}>
                <Ionicons name="close" size={22} color="#666" />
              </TouchableOpacity>
            </View>

            <Text style={styles.fieldLabel}>Avatar</Text>
            <View style={styles.avatarRow}>
              {avatarOptions.map(a => (
                <TouchableOpacity key={a} style={[styles.avatarOpt, form.avatar === a && styles.avatarOptActive]} onPress={() => setForm(f => ({ ...f, avatar: a }))}>
                  <Text style={styles.avatarOptEmoji}>{a}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={styles.fieldLabel}>Nome</Text>
            <TextInput
              style={styles.input}
              placeholder="Seu nome"
              value={form.name}
              onChangeText={v => setForm(f => ({ ...f, name: v }))}
            />

            <Text style={styles.fieldLabel}>Cidade</Text>
            <TextInput
              style={styles.input}
              placeholder="Sua cidade"
              value={form.city}
              onChangeText={v => setForm(f => ({ ...f, city: v }))}
            />

            <Text style={styles.fieldLabel}>WhatsApp (para trocas)</Text>
            <TextInput
              style={styles.input}
              placeholder="(11) 99999-9999"
              value={form.whatsapp}
              onChangeText={v => setForm(f => ({ ...f, whatsapp: v }))}
              keyboardType="phone-pad"
            />

            <TouchableOpacity style={styles.saveBtn} onPress={handleSave}>
              <Text style={styles.saveBtnText}>Salvar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f8f8f8' },

  profileHeader: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', padding: 16, gap: 12, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  avatarWrap: { width: 64, height: 64, borderRadius: 32, backgroundColor: '#e6f7ec', alignItems: 'center', justifyContent: 'center' },
  avatarEmoji: { fontSize: 32 },
  profileInfo: { flex: 1 },
  profileName: { fontSize: 17, fontWeight: '700', color: '#222' },
  profileCity: { fontSize: 13, color: '#999', marginTop: 2 },
  editBtn: { padding: 8 },

  statsCard: { backgroundColor: '#009C3B', margin: 12, borderRadius: 16, padding: 16 },
  bigStat: { alignItems: 'center', marginBottom: 10 },
  bigStatNum: { fontSize: 48, fontWeight: '800', color: '#FFD700' },
  bigStatLbl: { fontSize: 13, color: 'rgba(255,255,255,0.8)' },
  progressTrack: { height: 10, backgroundColor: 'rgba(255,255,255,0.3)', borderRadius: 5, overflow: 'hidden', marginBottom: 14 },
  progressFill: { height: '100%', backgroundColor: '#FFD700', borderRadius: 5 },
  statsGrid: { flexDirection: 'row' },
  statItem: { flex: 1, alignItems: 'center' },
  statNum: { fontSize: 20, fontWeight: '700', color: '#fff' },
  statLbl: { fontSize: 10, color: 'rgba(255,255,255,0.7)' },

  section: { backgroundColor: '#fff', margin: 12, marginTop: 0, marginBottom: 10, borderRadius: 14, padding: 14 },
  sectionTitle: { fontSize: 14, fontWeight: '700', color: '#222', marginBottom: 12 },

  groupRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  groupLabel: { fontSize: 12, color: '#666', width: 60 },
  groupTrack: { flex: 1, height: 6, backgroundColor: '#f0f0f0', borderRadius: 3, overflow: 'hidden' },
  groupFill: { height: '100%', backgroundColor: '#009C3B', borderRadius: 3 },
  groupPct: { fontSize: 11, fontWeight: '600', color: '#009C3B', width: 32, textAlign: 'right' },
  groupCount: { fontSize: 10, color: '#bbb', width: 36, textAlign: 'right' },

  topSelRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  topSelFlag: { fontSize: 20 },
  topSelName: { fontSize: 12, color: '#333', width: 80 },
  topSelTrack: { flex: 1, height: 6, backgroundColor: '#f0f0f0', borderRadius: 3, overflow: 'hidden' },
  topSelFill: { height: '100%', borderRadius: 3 },
  topSelPct: { fontSize: 11, fontWeight: '700', width: 36, textAlign: 'right' },

  repeatedGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  repChip: { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: '#FAEEDA', borderRadius: 10, paddingHorizontal: 8, paddingVertical: 4 },
  repFlag: { fontSize: 12 },
  repKey: { fontSize: 11, color: '#7a4000', fontWeight: '500' },
  repCount: { fontSize: 10, color: '#EF9F27', fontWeight: '700' },

  resetBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, padding: 14, borderRadius: 12, borderWidth: 1, borderColor: '#fce8e8', backgroundColor: '#fff5f5' },
  resetBtnText: { color: '#E24B4A', fontSize: 14, fontWeight: '600' },

  // Modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  modalCard: { backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24 },
  modalHeaderRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 },
  modalTitle: { fontSize: 17, fontWeight: '700', color: '#222' },
  fieldLabel: { fontSize: 12, color: '#999', fontWeight: '600', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  avatarRow: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  avatarOpt: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#f0f0f0', alignItems: 'center', justifyContent: 'center' },
  avatarOptActive: { backgroundColor: '#e6f7ec', borderWidth: 2, borderColor: '#009C3B' },
  avatarOptEmoji: { fontSize: 22 },
  input: { backgroundColor: '#f8f8f8', borderRadius: 10, padding: 12, fontSize: 15, color: '#222', marginBottom: 14, borderWidth: 1, borderColor: '#f0f0f0' },
  saveBtn: { backgroundColor: '#009C3B', borderRadius: 14, padding: 16, alignItems: 'center', marginTop: 4 },
  saveBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
