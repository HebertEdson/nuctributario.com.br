import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  FlatList, Modal, SafeAreaView, TextInput, StatusBar, Alert
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { SELECOES, TOTAL_STICKERS, getStickerKey, getGroups } from '../data/album2026';
import { getStickers, addSticker, removeSticker, getStats } from '../database/db';

const GROUPS = ['A','B','C','D','E','F','G','H','I','J','K','L'];

export default function AlbumScreen() {
  const [stickers, setStickers] = useState({});
  const [stats, setStats] = useState({ owned: 0, missing: 980, totalRepeated: 0, pct: 0 });
  const [selectedGroup, setSelectedGroup] = useState('ALL');
  const [selectedSelecao, setSelectedSelecao] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [search, setSearch] = useState('');

  useFocusEffect(useCallback(() => {
    loadStickers();
  }, []));

  const loadStickers = async () => {
    const s = await getStickers();
    setStickers(s);
    setStats(getStats(s, TOTAL_STICKERS));
  };

  const handleStickerPress = async (selecaoId, num) => {
    const key = getStickerKey(selecaoId, num);
    const newStickers = await addSticker(key);
    setStickers({ ...newStickers });
    setStats(getStats(newStickers, TOTAL_STICKERS));
  };

  const handleStickerLongPress = async (selecaoId, num) => {
    const key = getStickerKey(selecaoId, num);
    const count = stickers[key] || 0;
    if (count === 0) return;
    Alert.alert(
      'Remover figurinha',
      `Remover uma figurinha de ${selecaoId} #${num}?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Remover', style: 'destructive', onPress: async () => {
          const newStickers = await removeSticker(key);
          setStickers({ ...newStickers });
          setStats(getStats(newStickers, TOTAL_STICKERS));
        }},
      ]
    );
  };

  const openSelecao = (selecao) => {
    setSelectedSelecao(selecao);
    setModalVisible(true);
  };

  const filteredSelecoes = SELECOES.filter(s => {
    const matchGroup = selectedGroup === 'ALL' || s.group === selectedGroup;
    const matchSearch = !search || s.name.toLowerCase().includes(search.toLowerCase()) || s.id.toLowerCase().includes(search.toLowerCase());
    return matchGroup && matchSearch;
  });

  const getSelecaoProgress = (selecao) => {
    const owned = selecao.stickers.filter(st => (stickers[getStickerKey(selecao.id, st.num)] || 0) >= 1).length;
    return { owned, total: selecao.stickers.length };
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />

      {/* Header Stats */}
      <View style={styles.statsHeader}>
        <View style={styles.statsMain}>
          <Text style={styles.statsTitle}>Álbum Copa 2026</Text>
          <Text style={styles.statsSubtitle}>Panini FIFA World Cup™</Text>
        </View>
        <View style={styles.statsNumbers}>
          <View style={styles.statItem}>
            <Text style={styles.statNum}>{stats.owned}</Text>
            <Text style={styles.statLbl}>Tenho</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={[styles.statNum, { color: '#E24B4A' }]}>{stats.missing}</Text>
            <Text style={styles.statLbl}>Faltam</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={[styles.statNum, { color: '#EF9F27' }]}>{stats.totalRepeated}</Text>
            <Text style={styles.statLbl}>Repetidas</Text>
          </View>
        </View>
        <View style={styles.progressRow}>
          <View style={styles.progressTrack}>
            <View style={[styles.progressFill, { width: `${stats.pct}%` }]} />
          </View>
          <Text style={styles.progressPct}>{stats.pct}%</Text>
        </View>
      </View>

      {/* Search */}
      <View style={styles.searchRow}>
        <View style={styles.searchBox}>
          <Ionicons name="search" size={16} color="#999" />
          <TextInput
            style={styles.searchInput}
            placeholder="Buscar seleção..."
            placeholderTextColor="#bbb"
            value={search}
            onChangeText={setSearch}
          />
          {search ? (
            <TouchableOpacity onPress={() => setSearch('')}>
              <Ionicons name="close-circle" size={16} color="#bbb" />
            </TouchableOpacity>
          ) : null}
        </View>
      </View>

      {/* Group Tabs */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.groupTabsScroll} contentContainerStyle={styles.groupTabs}>
        <TouchableOpacity
          style={[styles.groupTab, selectedGroup === 'ALL' && styles.groupTabActive]}
          onPress={() => setSelectedGroup('ALL')}
        >
          <Text style={[styles.groupTabText, selectedGroup === 'ALL' && styles.groupTabTextActive]}>Todos</Text>
        </TouchableOpacity>
        {GROUPS.map(g => (
          <TouchableOpacity
            key={g}
            style={[styles.groupTab, selectedGroup === g && styles.groupTabActive]}
            onPress={() => setSelectedGroup(g)}
          >
            <Text style={[styles.groupTabText, selectedGroup === g && styles.groupTabTextActive]}>Grupo {g}</Text>
          </TouchableOpacity>
        ))}
        <TouchableOpacity
          style={[styles.groupTab, selectedGroup === 'ESP' && styles.groupTabActive]}
          onPress={() => setSelectedGroup('ESP')}
        >
          <Text style={[styles.groupTabText, selectedGroup === 'ESP' && styles.groupTabTextActive]}>✨ Especiais</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Seleções Grid */}
      <FlatList
        data={filteredSelecoes}
        numColumns={2}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.selecaoList}
        renderItem={({ item }) => {
          const { owned, total } = getSelecaoProgress(item);
          const pct = Math.round(owned / total * 100);
          const complete = owned === total;
          return (
            <TouchableOpacity
              style={[styles.selecaoCard, complete && styles.selecaoCardComplete]}
              onPress={() => openSelecao(item)}
              activeOpacity={0.7}
            >
              <Text style={styles.selecaoFlag}>{item.flag}</Text>
              <Text style={styles.selecaoName} numberOfLines={1}>{item.name}</Text>
              <Text style={styles.selecaoGroup}>Grupo {item.group}</Text>
              <View style={styles.selecaoProgressTrack}>
                <View style={[styles.selecaoProgressFill, { width: `${pct}%`, backgroundColor: item.color }]} />
              </View>
              <Text style={[styles.selecaoProgressText, { color: item.color }]}>{owned}/{total}</Text>
              {complete && (
                <View style={[styles.completeBadge, { backgroundColor: item.color }]}>
                  <Ionicons name="checkmark" size={10} color="#fff" />
                </View>
              )}
            </TouchableOpacity>
          );
        }}
      />

      {/* Modal de Seleção */}
      <Modal visible={modalVisible} animationType="slide" onRequestClose={() => setModalVisible(false)}>
        {selectedSelecao && (
          <SafeAreaView style={styles.modalSafe}>
            <View style={[styles.modalHeader, { backgroundColor: selectedSelecao.color }]}>
              <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.modalBack}>
                <Ionicons name="arrow-back" size={24} color="#fff" />
              </TouchableOpacity>
              <View style={styles.modalTitleRow}>
                <Text style={styles.modalFlag}>{selectedSelecao.flag}</Text>
                <View>
                  <Text style={styles.modalTitle}>{selectedSelecao.name}</Text>
                  <Text style={styles.modalSubtitle}>Grupo {selectedSelecao.group} · 20 figurinhas</Text>
                </View>
              </View>
            </View>

            <View style={styles.modalLegend}>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: '#eee', borderColor: '#ddd', borderWidth: 1 }]} />
                <Text style={styles.legendText}>Falta</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: selectedSelecao.colorLight }]} />
                <Text style={styles.legendText}>Tenho</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: '#FAEEDA' }]} />
                <Text style={styles.legendText}>Repetida</Text>
              </View>
              <Text style={styles.legendHint}>Toque = +1 · Segure = -1</Text>
            </View>

            <FlatList
              data={selectedSelecao.stickers}
              numColumns={4}
              keyExtractor={item => String(item.num)}
              contentContainerStyle={styles.stickerGrid}
              renderItem={({ item }) => {
                const key = getStickerKey(selectedSelecao.id, item.num);
                const count = stickers[key] || 0;
                const isOwned = count >= 1;
                const isRepeated = count > 1;
                return (
                  <TouchableOpacity
                    style={[
                      styles.stickerCell,
                      isRepeated ? styles.stickerRepeated :
                      isOwned ? [styles.stickerOwned, { backgroundColor: selectedSelecao.colorLight, borderColor: selectedSelecao.color }] :
                      styles.stickerMissing
                    ]}
                    onPress={() => handleStickerPress(selectedSelecao.id, item.num)}
                    onLongPress={() => handleStickerLongPress(selectedSelecao.id, item.num)}
                    activeOpacity={0.7}
                  >
                    {isRepeated && (
                      <View style={[styles.repeatBadge, { backgroundColor: '#EF9F27' }]}>
                        <Text style={styles.repeatBadgeText}>x{count}</Text>
                      </View>
                    )}
                    <Text style={styles.stickerNum}>{item.num}</Text>
                    <Text style={styles.stickerName} numberOfLines={2}>{item.name}</Text>
                  </TouchableOpacity>
                );
              }}
            />
          </SafeAreaView>
        )}
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#fff' },
  statsHeader: {
    backgroundColor: '#009C3B',
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 14,
  },
  statsMain: { marginBottom: 8 },
  statsTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  statsSubtitle: { color: 'rgba(255,255,255,0.75)', fontSize: 12 },
  statsNumbers: { flexDirection: 'row', marginBottom: 10 },
  statItem: { flex: 1, alignItems: 'center' },
  statNum: { color: '#fff', fontSize: 22, fontWeight: '700' },
  statLbl: { color: 'rgba(255,255,255,0.75)', fontSize: 11 },
  statDivider: { width: 1, backgroundColor: 'rgba(255,255,255,0.3)', marginHorizontal: 4 },
  progressRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  progressTrack: { flex: 1, height: 8, backgroundColor: 'rgba(255,255,255,0.3)', borderRadius: 4, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: '#FFD700', borderRadius: 4 },
  progressPct: { color: '#FFD700', fontWeight: '700', fontSize: 14, minWidth: 36 },

  searchRow: { paddingHorizontal: 12, paddingVertical: 8, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  searchBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f5f5f5', borderRadius: 10, paddingHorizontal: 10, height: 36, gap: 6 },
  searchInput: { flex: 1, fontSize: 14, color: '#333' },

  groupTabsScroll: { maxHeight: 44, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  groupTabs: { paddingHorizontal: 8, alignItems: 'center', gap: 6 },
  groupTab: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, backgroundColor: '#f5f5f5' },
  groupTabActive: { backgroundColor: '#009C3B' },
  groupTabText: { fontSize: 12, color: '#666', fontWeight: '500' },
  groupTabTextActive: { color: '#fff' },

  selecaoList: { padding: 10, gap: 8 },
  selecaoCard: {
    flex: 1, margin: 4, backgroundColor: '#fff',
    borderRadius: 12, padding: 12, alignItems: 'center',
    borderWidth: 1, borderColor: '#eee',
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2,
    position: 'relative',
  },
  selecaoCardComplete: { borderColor: '#009C3B', borderWidth: 1.5 },
  selecaoFlag: { fontSize: 32, marginBottom: 4 },
  selecaoName: { fontSize: 13, fontWeight: '600', color: '#222', textAlign: 'center' },
  selecaoGroup: { fontSize: 10, color: '#999', marginBottom: 6 },
  selecaoProgressTrack: { width: '100%', height: 4, backgroundColor: '#f0f0f0', borderRadius: 2, overflow: 'hidden', marginBottom: 4 },
  selecaoProgressFill: { height: '100%', borderRadius: 2 },
  selecaoProgressText: { fontSize: 11, fontWeight: '600' },
  completeBadge: { position: 'absolute', top: 8, right: 8, width: 18, height: 18, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },

  // Modal
  modalSafe: { flex: 1, backgroundColor: '#f8f8f8' },
  modalHeader: { flexDirection: 'row', alignItems: 'center', padding: 16, paddingTop: 12, gap: 12 },
  modalBack: { padding: 4 },
  modalTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  modalFlag: { fontSize: 36 },
  modalTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  modalSubtitle: { color: 'rgba(255,255,255,0.8)', fontSize: 12 },
  modalLegend: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 8, backgroundColor: '#fff', gap: 12, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  legendDot: { width: 12, height: 12, borderRadius: 3 },
  legendText: { fontSize: 11, color: '#666' },
  legendHint: { marginLeft: 'auto', fontSize: 10, color: '#bbb', fontStyle: 'italic' },

  stickerGrid: { padding: 8 },
  stickerCell: {
    flex: 1, margin: 4, aspectRatio: 0.75, borderRadius: 8, alignItems: 'center', justifyContent: 'center',
    padding: 4, position: 'relative', borderWidth: 1,
  },
  stickerMissing: { backgroundColor: '#f5f5f5', borderColor: '#e0e0e0' },
  stickerOwned: { borderWidth: 1.5 },
  stickerRepeated: { backgroundColor: '#FAEEDA', borderColor: '#EF9F27', borderWidth: 1.5 },
  repeatBadge: { position: 'absolute', top: -4, right: -4, borderRadius: 8, paddingHorizontal: 4, paddingVertical: 1 },
  repeatBadgeText: { color: '#fff', fontSize: 8, fontWeight: '700' },
  stickerNum: { fontSize: 14, fontWeight: '700', color: '#333' },
  stickerName: { fontSize: 8, color: '#666', textAlign: 'center', marginTop: 2 },
});
