# 🏆 Álbum Copa 2026 — App Mobile

App mobile completo para gerenciar o álbum de figurinhas Panini FIFA World Cup 2026™.

## 📱 Funcionalidades

### 🎴 Álbum
- Todas as **980 figurinhas** organizadas por grupo (A–L) e seleção
- **48 seleções** com numeração real do álbum Panini (1–20 por país)
- **68 figurinhas especiais** (escudos, estádios, institucionais)
- Visual com cores de cada seleção, progresso individual e geral
- Toque para adicionar | Segure para remover
- Filtro por grupo e busca por seleção

### 📷 Scanner
- **Câmera do celular** para fotografar figurinhas
- **Reconhecimento por IA** (pronto para integrar com a API da Anthropic)
- Busca manual por seleção, jogador ou número
- Histórico das últimas figurinhas adicionadas
- Alerta de figurinha repetida antes de confirmar

### 🔄 Trocas
- Lista suas **figurinhas repetidas disponíveis**
- Encontra pessoas próximas com figurinhas para trocar
- **Match automático**: destaca quando alguém tem o que você precisa
- Botão de **WhatsApp** para contato direto com mensagem pré-preenchida
- Compartilha sua lista de repetidas

### 👤 Perfil
- Estatísticas detalhadas: % completo, por grupo, por seleção
- Seleções mais completas
- Lista completa de figurinhas repetidas
- Configuração de nome, cidade e WhatsApp para aparecer nas trocas

---

## 🚀 Como instalar e rodar

### Pré-requisitos
- **Node.js** 18+ instalado
- **Expo Go** instalado no celular (Android/iOS) — App gratuito
- Celular e computador na **mesma rede Wi-Fi**

### Instalação

```bash
# 1. Entrar na pasta do projeto
cd "C:\Users\FAMILIA\Desktop\album"

# 2. Instalar dependências
npm install

# 3. Rodar o app
npx expo start
```

### Abrindo no celular

1. Abra o **Expo Go** no celular
2. Escaneie o **QR Code** que aparece no terminal
3. O app abrirá diretamente no celular! ✅

---

## 📦 Estrutura do projeto

```
album/
├── App.js                    ← Navegação principal
├── app.json                  ← Configurações do app (permissões, ícone)
├── src/
│   ├── data/
│   │   └── album2026.js      ← Todas as 980 figurinhas (48 seleções)
│   ├── database/
│   │   └── db.js             ← Persistência local (AsyncStorage)
│   └── screens/
│       ├── AlbumScreen.js    ← Álbum principal
│       ├── ScannerScreen.js  ← Câmera + Scanner IA
│       ├── TrocasScreen.js   ← Área de trocas
│       └── PerfilScreen.js   ← Perfil e estatísticas
```

---

## 🤖 Integrar reconhecimento real por IA

O scanner já está preparado. Para ativar o reconhecimento real com a API da Anthropic:

1. Abra `src/screens/ScannerScreen.js`
2. Substitua a função `recognizeSticker` por:

```javascript
const recognizeSticker = async (imageBase64) => {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": "SUA_CHAVE_API_AQUI",
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: "claude-opus-4-5",
      max_tokens: 500,
      messages: [{
        role: "user",
        content: [
          {
            type: "image",
            source: { type: "base64", media_type: "image/jpeg", data: imageBase64 }
          },
          {
            type: "text",
            text: `Esta é uma figurinha do álbum Panini Copa do Mundo 2026. 
            Identifique: qual seleção (ex: BRA, ARG, FRA...) e o número (1-20).
            Responda APENAS em JSON: {"selecaoId": "BRA", "num": 11, "confidence": 0.95}`
          }
        ]
      }]
    })
  });
  const data = await response.json();
  const parsed = JSON.parse(data.content[0].text);
  // Buscar dados da figurinha no banco local
  const sel = SELECOES.find(s => s.id === parsed.selecaoId);
  const st = sel?.stickers.find(s => s.num === parsed.num);
  return {
    selecaoId: parsed.selecaoId,
    num: parsed.num,
    name: st?.name || `#${parsed.num}`,
    selecaoName: sel?.name || parsed.selecaoId,
    flag: sel?.flag || '🏳️',
    confidence: parsed.confidence
  };
};
```

---

## 🌐 Adicionar backend real para Trocas

Para trocas entre usuários reais, o projeto está pronto para integrar com:
- **Firebase Firestore** — banco de dados em tempo real
- **Supabase** — alternativa open-source ao Firebase
- **Socket.io** — para chat em tempo real

Os dados de usuários mockados estão em `src/screens/TrocasScreen.js` (constante `MOCK_USERS`).

---

## 📊 Dados do Álbum

- **Total**: 980 figurinhas
- **Seleções**: 48 países (Grupos A–L)
- **Por seleção**: 20 figurinhas (escudo, 2 goleiros, defensores, meio-campistas, atacantes, equipe)
- **Especiais**: 68 cromos metalizados (4 institucionais + 16 estádios + 48 escudos)
- **Numeração**: por país (1–20), conforme o álbum oficial Panini 2026

---

## ✅ Tecnologias

| Tecnologia | Uso |
|---|---|
| React Native + Expo | Framework mobile |
| Expo Camera | Acesso à câmera |
| AsyncStorage | Banco local persistente |
| React Navigation | Navegação por tabs |
| @expo/vector-icons | Ícones (Ionicons) |

---

*Desenvolvido para a família com ❤️ — Copa do Mundo FIFA 2026™*
